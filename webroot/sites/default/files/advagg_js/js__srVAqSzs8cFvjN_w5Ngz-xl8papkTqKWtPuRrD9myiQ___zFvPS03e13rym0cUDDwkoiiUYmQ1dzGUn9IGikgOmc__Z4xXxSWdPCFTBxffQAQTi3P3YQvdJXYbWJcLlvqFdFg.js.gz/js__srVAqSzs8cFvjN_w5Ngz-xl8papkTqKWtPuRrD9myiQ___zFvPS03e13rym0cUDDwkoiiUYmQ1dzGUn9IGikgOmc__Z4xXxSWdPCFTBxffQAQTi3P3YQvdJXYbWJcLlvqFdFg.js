window.CKEDITOR_BASEPATH = '/sites/all/libraries/ckeditor/';
;/*})'"*/
;/*})'"*/
